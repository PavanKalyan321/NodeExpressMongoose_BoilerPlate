const express = require('express');
const { default: mongoose } = require('mongoose');
const app = express();
const bodyparser = require('body-parser');
// Middlewares
const Routes = require('./routes/routes.js');
app.use(bodyparser.json())
app.use('/',Routes)


mongoose.connect('mongodb+srv://PavanKalyan123:Pavan123@cluster0.0e0nf.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',{useNewURlParser:true},()=>{
    console.log('connected');
})


app.listen(3001);