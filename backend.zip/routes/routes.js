const express = require('express');
const res = require('express/lib/response');
const user = require('../models/user');
const router = express.Router();
const procurement = require('../models/procurement');
const finance = require('../models/finance');
const logistics = require('../models/logistics');

router.post('/login', (req, res) => {
    user.findOne({
        userName: req.body.userName,
        password: req.body.password
    }).exec()
        .then((response) => {
            // console.log(response);
            res.json({ response: response, status: 201 })
        }).catch((Err) => {
            console.json({ message: Err, status: 404 });
        })
})

router.post('/signup', (req, res) => {
    // console.log(req.body);
    const newuser = new user({
        userName: req.body.userName,
        password: req.body.password
    })
    newuser.save().then((response) => {
        // console.log(response);
        res.json({ message: 'saved', status: 200 });
    }).catch((Err) => {
        console.log(Err);
        res.json({ message: Err, status: 400 });
    })
})

router.get('/getProcurement', (req, res) => {
    procurement.find().all()
        .then((Response) => {
            res.json({ data: Response });
        }).catch((Err) => {
            res.json({ Err: Err })
        })
})

router.post('/Procurement', (req, res) => {
    const newProc = new procurement({
        projectID: req.body.projectID,
        quantity: req.body.quantity,
        requiredDate: req.body.requiredDate
    })
    newProc.save()
        .then((Response) => {
            res.json({ message: Response, status: 200 });
        }).catch((Err) => {
            res.json({ Err: Err, status: 400 });
        })
})

router.put('/updateProcurement', (req, res) => {
    procurement.findOneAndUpdate({
        projectID: req.body.projectID
    }, {
        approvedByProcurement:req.body.approvedByProcurement
    },{
        new: true
    }).then((Response)=>{
        res.json({message:Response,status:200})
    }).catch((Err)=>{
        res.json({message:Err,status:400})
    })
})



router.get('/getFinance', (req, res) => {
    finance.find().all()
        .then((Response) => {
            res.json({ data: Response });
        }).catch((Err) => {
            res.json({ Err: Err });
        })
})

router.post('/Finance', (req, res) => {
    const newFinance = new finance({
        projectID: req.body.projectID,
        quantity: req.body.quantity,
        requiredDate: req.body.requiredDate,
        approvedByProcurement: req.body.approvedByProcurement,
    })
    newFinance.save()
        .then((Response) => {
            res.json({ message: Response, status: 200 });
        }).catch((Err) => {
            res.json({ Err: Err, status: 400 });
        })
})

router.put('/updateFinance', (req, res) => {
    finance.findOneAndUpdate({
        projectID: req.body.projectID
    }, {
        approvedByFinance:req.body.approvedByFinance
    },{
        new: true
    }).then((Response)=>{
        res.json({message:Response,status:200})
    }).catch((Err)=>{
        res.json({message:Err,status:400})
    })
})



router.get('/getLogistics', (req, res) => {
    logistics.find().all()
        .then((Response) => {
            res.json({ data: Response });
        }).catch((Err) => {
            res.json({ Err: Err });
        })
})

router.post('/Logistics', (req, res) => {
    const newLogistics = new logistics({
        projectID: req.body.projectID,
        quantity: req.body.quantity,
        requiredDate: req.body.requiredDate,
        approvedByProcurement: req.body.approvedByProcurement,
        approvedByFinance: req.body.approvedByFinance,
    })
    newLogistics.save()
        .then((Response) => {
            res.json({ message: Response, status: 200 });
        }).catch((Err) => {
            res.json({ Err: Err, status: 400 });
        })
})

router.put('/updateLogistics', (req, res) => {
    logistics.findOneAndUpdate({
        projectID: req.body.projectID
    }, {
        approvedByLogistics:req.body.approvedByLogistics
    },{
        new: true
    }).then((Response)=>{
        res.json({message:Response,status:200})
    }).catch((Err)=>{
        res.json({message:Err,status:400})
    })
})


module.exports = router;