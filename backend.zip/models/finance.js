const mongoose = require('mongoose');

const FinanceSchema = mongoose.Schema({
    projectID:String,
    quantity:Number,
    requiredDate:String,
    approvedByProcurement:{
        default:false,
        type:Boolean
    },
    approvedByFinance:{
        default:false,
        type:Boolean
    },
    
});

module.exports=mongoose.model('finance',FinanceSchema);