const mongoose = require('mongoose');

const LogisticsSchema = mongoose.Schema({
    projectID:String,
    quantity:Number,
    requiredDate:String,
    approvedByProcurement:{
        default:false,
        type:Boolean
    },
    approvedByFinance:{
        default:false,
        type:Boolean
    },
    approvedByLogistics:{
        default:false,
        type:Boolean
    },
});

module.exports=mongoose.model('logistics',LogisticsSchema);