const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    userName:{
        type:String,
        required:String
    },
    password:{
        type:String,
        required:String
    },
    UniqueID:String,
});

module.exports=mongoose.model('users',userSchema);