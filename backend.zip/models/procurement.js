const mongoose = require('mongoose');

const ProcumrentSchema = mongoose.Schema({
    projectID:String,
    quantity:Number,
    requiredDate:String,
    approvedByProcurement:{
        default:false,
        type:Boolean
    }
});

module.exports=mongoose.model('procurement',ProcumrentSchema);